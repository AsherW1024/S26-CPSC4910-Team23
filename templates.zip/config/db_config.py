DB_USER = "CPSC4911_admin"
DB_PASSWORD = "AmR3rnvsSJRrJaMJ5Jt2"
DB_HOST = "cpsc4910-s26.cobd8enwsupz.us-east-1.rds.amazonaws.com"
DB_NAME = "Team23_DB"